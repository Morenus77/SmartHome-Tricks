#!/usr/bin/env python3
"""
ingest_to_mongo.py — Scrive un documento in MongoDB secondo il contratto definito in schemas/ e config/collections.yml.

Uso:
    MONGO_URI=mongodb://... python3 ingest_to_mongo.py record.json
    echo '{"type":"Veicoli",...}' | python3 ingest_to_mongo.py --stdin

Caratteristiche:
- Validazione contro schemas/common.json + schemas/<type>.json
- Routing DB/collection da config/collections.yml
- Upsert idempotente su chiave dichiarativa in config/collections.yml
  (types.<type>.idempotency), basata sui dati del documento, mai sul nome file.
  Fallback: _id (hash deterministico del contenuto).
- Modalità --dry-run: valida + mostra routing senza scrivere
- Modalità --confirm: prompt interattivo per ogni record (default in modalità REPL)
"""

import argparse
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml
    from pymongo import MongoClient
    from pymongo.errors import DuplicateKeyError, ServerSelectionTimeoutError
    from jsonschema import validate, ValidationError
except ImportError as e:
    sys.exit(f"Dipendenza mancante: {e}\nInstalla con: .venv/bin/pip install pymongo pyyaml jsonschema")

SKILL_DIR = Path(__file__).resolve().parent.parent
SCHEMAS_DIR = SKILL_DIR / "schemas"
CONFIG_FILE = SKILL_DIR / "config" / "collections.yml"


def load_config() -> dict:
    with open(CONFIG_FILE) as f:
        return yaml.safe_load(f)


def load_schema(type_name: str) -> dict:
    path = SCHEMAS_DIR / "common.json"
    with open(path) as f:
        common = json.load(f)
    specific_path = SCHEMAS_DIR / f"{type_name.lower()}.json"
    if specific_path.exists():
        with open(specific_path) as f:
            specific = json.load(f)
        # Merge: required union, properties union (specific override common);
        # additionalProperties follows the specific schema when it declares it.
        merged = {
            "type": "object",
            "required": list(set(common.get("required", [])) | set(specific.get("required", []))),
            "properties": {**common.get("properties", {}), **specific.get("properties", {})},
            "additionalProperties": specific.get("additionalProperties", common.get("additionalProperties", True)),
        }
        return merged
    return common


def validate_record(record: dict, schema: dict) -> None:
    try:
        validate(instance=record, schema=schema)
    except ValidationError as e:
        sys.exit(f"ERRORE validazione: {e.message}\nPath: {'.'.join(str(p) for p in e.absolute_path)}")


def determine_target(record: dict, config: dict, force_confirm: bool = False) -> tuple[str, str]:
    """Ritorna (db_name, collection_name). Può chiedere conferma interattiva."""
    type_name = record["type"]
    type_cfg = config["types"].get(type_name)
    if not type_cfg:
        print(f"\nTipo '{type_name}' non riconosciuto nel config.")
        print("Tipi disponibili:", list(config["types"].keys()))
        new_db = input("DB (vuoto per annullare): ").strip()
        if not new_db:
            sys.exit("Annullato.")
        new_col = input("Collection: ").strip() or "default"
        return new_db, new_col

    db = type_cfg["db"]
    collections = type_cfg["collections"]
    id_field = type_cfg.get("id_collection", "fornitore")

    if len(collections) == 1:
        return db, collections[0]

    # Più collection: routing per id_field (fornitore, targa, ecc.)
    value = record.get(id_field, "")
    if value in collections:
        if not force_confirm:
            return db, value
    print(f"\nRouting ambiquo: type={type_name}, {id_field}={value!r}")
    print(f"Collection disponibili in {db}: {collections}")
    print("  [N] Nuova collection")
    print("  [Q] Esci")
    for i, c in enumerate(collections, 1):
        print(f"  [{i}] {c}")
    while True:
        choice = input("Scelta: ").strip()
        if choice.upper() == "Q":
            sys.exit("Annullato.")
        if choice.upper() == "N":
            new = input("Nome nuova collection: ").strip()
            if new:
                return db, new
            continue
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(collections):
                return db, collections[idx]
        except ValueError:
            pass
        print("Scelta non valida.")


def build_idempotency_key(record: dict, config: dict) -> dict:
    """Costruisce il filtro di upsert basandosi esclusivamente sui dati del documento.

    Chiave dichiarativa in config/collections.yml -> types.<type>.idempotency.
    Per ogni spec (in ordine di priorità):
      - requires: campi che devono TUTTI essere valorizzati perché la spec si applichi;
      - key:      campi aggiuntivi sempre presenti nella chiave (valore = record.get(f, ""));
      - optional: campi inclusi nella chiave SOLO se valorizzati.
    Fallback implicito: _id (hash deterministico del contenuto).
    """
    type_name = record["type"]
    specs = config["types"].get(type_name, {}).get("idempotency")
    if not specs:
        specs = [
            {"requires": ["numero_documento", "fornitore"], "optional": ["tipo_intervento"]},
        ]
    for spec in specs:
        required = spec.get("requires", [])
        if all(record.get(f) not in (None, "", []) for f in required):
            key = {"type": type_name}
            for f in required + spec.get("key", []):
                key[f] = record.get(f, "")
            for f in spec.get("optional", []):
                v = record.get(f)
                if v not in (None, "", []):
                    key[f] = v
            return key
    return {"type": type_name, "_id": record["_id"]}


def show_summary(record: dict, db: str, col: str, key: dict) -> None:
    print("\n" + "=" * 60)
    print(f"TIPO:    {record['type']}")
    print(f"DB:      {db}")
    print(f"COLL:    {col}")
    print(f"CHIAVE:  {key}")
    print("-" * 60)
    # Mostra i campi significativi: tutti tranne l'envelope tecnico
    nested = {"voci", "corse", "componenti", "garanzie"}
    for field in sorted(record):
        value = record[field]
        if field in ("_id", "type", "acquisito_il") or value in (None, "", []):
            continue
        if field in nested:
            print(f"  {field:20s} = {len(value)} elementi")
        elif field == "note":
            print(f"  {'note':20s} = {str(value)[:80]}")
        else:
            print(f"  {field:20s} = {value}")
    print("=" * 60)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file", nargs="?", help="File JSON con il record (o --stdin)")
    ap.add_argument("--stdin", action="store_true")
    ap.add_argument("--dry-run", action="store_true", help="Valida + mostra routing, non scrive")
    ap.add_argument("--confirm", action="store_true", default=True, help="Prompt prima di scrivere (default)")
    ap.add_argument("--yes", "-y", action="store_true", help="Salta prompt di conferma")
    args = ap.parse_args()

    # 1. Carica record
    if args.stdin:
        record = json.load(sys.stdin)
    else:
        if not args.file:
            ap.error("Specifica file o --stdin")
        with open(args.file) as f:
            record = json.load(f)

    # 2. Assicura _id e acquisito_il se mancanti
    if "_id" not in record:
        record["_id"] = hashlib.sha256(
            json.dumps(record, sort_keys=True, default=str).encode()
        ).hexdigest()[:24]
    if "acquisito_il" not in record:
        record["acquisito_il"] = datetime.now(timezone.utc).date().isoformat()

    # 3. Carica config e schema
    config = load_config()
    schema = load_schema(record["type"])
    validate_record(record, schema)

    # 4. Determina target (con prompt se ambiquo o se --confirm senza --yes)
    force_confirm = args.confirm and not args.yes
    db_name, col_name = determine_target(record, config, force_confirm=force_confirm)

    # 5. Costruisci chiave idempotenza
    key = build_idempotency_key(record, config)

    # 6. Mostra sommario
    show_summary(record, db_name, col_name, key)

    if args.dry_run:
        print("\n[DRY-RUN] Nessuna scrittura eseguita.")
        return

    # 7. Conferma (solo se non --yes)
    if not args.yes:
        resp = input("\nProcedere con l'upsert? [s/N]: ").strip().lower()
        if resp != "s":
            print("Annullato.")
            return

    # 8. Scrivi
    uri = os.environ.get("MONGO_URI")
    if not uri:
        sys.exit("MONGO_URI non impostata. Esportala e rilancia.")
    try:
        client = MongoClient(uri, serverSelectionTimeoutMS=5000)
        client.admin.command("ping")
    except ServerSelectionTimeoutError as e:
        sys.exit(f"Impossibile connettersi a Mongo: {e}")

    coll = client[db_name][col_name]
    # Crea indice unico sulla chiave idempotente se non esiste
    idx_fields = list(key.keys())
    try:
        coll.create_index(idx_fields, unique=False, name="idempotency_idx")
    except Exception as e:
        print(f"  (indice già esistente o non creabile: {e})")

    # $set esclude _id (immutabile) — se la chiave è basata su _id, non includerlo
    set_fields = {k: v for k, v in record.items() if k != "_id"}
    result = coll.update_one(key, {"$set": set_fields}, upsert=True)
    action = "INSERITO" if result.upserted_id else "AGGIORNATO"
    print(f"\n✓ {action} in {db_name}.{col_name}")
    print(f"  Matched: {result.matched_count}, Modified: {result.modified_count}, Upserted: {result.upserted_id}")


if __name__ == "__main__":
    main()
