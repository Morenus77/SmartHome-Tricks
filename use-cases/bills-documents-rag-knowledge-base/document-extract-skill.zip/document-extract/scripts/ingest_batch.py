#!/usr/bin/env python3
"""
ingest_batch.py — Produzione del MATERIALE di estrazione per una cartella di PDF.

Pipeline generica (indipendente dal tipo): scansiona PDF → text-layer (o OCR se scan)
→ cache → primitivi generici (candidati esatti, da extractor.py). Il risultato per ogni
file è il "materiale" {file, path, type, lines, candidati}: le righe agnostiche, il
percorso (per il contesto di cartella) e i valori esatti. Il MODELLO (Claude Code)
compila il record secondo lo schema e le regole di SKILL.md (§7): classifica lui
forma_documento / tipo_soggetto / tipo_intervento e decide gli skip.

Uso:
    python3 ingest_batch.py <cartella> --type Assicurazioni \
      [--subdirs "<sottocartella1>" ...] [--material /tmp/material] [--limit N]

Dopo la produzione del materiale, l'agente interpreta (compila i record), valida con
`ingest_to_mongo.py --dry-run` e importa con `--yes`.
"""

import argparse
import hashlib
import json
import re
import subprocess
import tempfile
from pathlib import Path

from extractor import material

SKILL_DIR = Path(__file__).resolve().parent.parent
SCRIPTS = SKILL_DIR / "scripts"


def run(cmd: list[str]) -> str:
    return subprocess.run(cmd, capture_output=True, text=True).stdout


def text_layer(pdf: Path) -> str:
    return run(["swift", str(SCRIPTS / "pdf_to_text.swift"), str(pdf)])


def ocr_pdf(pdf: Path, outdir: Path) -> list[dict]:
    """Ritorna lista di righe OCR: {y, x, text} per tutte le pagine."""
    run(["swift", str(SCRIPTS / "pdf_to_pages.swift"), str(pdf), str(outdir)])
    lines = []
    for png in sorted(outdir.glob("page*.png")):
        out = run(["swift", str(SCRIPTS / "ocr_vision.swift"), str(png)])
        for row in out.splitlines():
            m = re.match(r"\[y=([\d.]+) x=([\d.]+)\] (.*)", row)
            if m:
                lines.append({
                    "y": float(m.group(1)),
                    "x": float(m.group(2)),
                    "text": m.group(3).strip(),
                    "page": png.name,
                })
    return lines


CACHE_DIR = Path("/tmp/ingest_cache")


def cache_get(pdf: Path) -> list[dict] | None:
    """Ritorna le righe OCR/text-layer dal cache se disponibili."""
    st = pdf.stat()
    key = hashlib.sha256(f"{pdf.name}|{st.st_size}|{st.st_mtime}".encode()).hexdigest()[:16]
    cache_file = CACHE_DIR / f"{key}.json"
    if cache_file.exists():
        with open(cache_file) as f:
            return json.load(f)
    return None


def cache_put(pdf: Path, lines: list[dict]) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    st = pdf.stat()
    key = hashlib.sha256(f"{pdf.name}|{st.st_size}|{st.st_mtime}".encode()).hexdigest()[:16]
    with open(CACHE_DIR / f"{key}.json", "w") as f:
        json.dump(lines, f)


def process_pdf(type_name: str, pdf: Path, folder: Path, tmp: Path) -> dict:
    """Ritorna il materiale {file, path, type, lines, candidati} per il PDF."""
    cached = cache_get(pdf)
    if cached is not None:
        lines = cached
        print(f"  (cache)")
    else:
        text = text_layer(pdf)
        if not text.strip():
            workdir = tmp / pdf.stem
            workdir.mkdir(parents=True, exist_ok=True)
            lines = ocr_pdf(pdf, workdir)
            for l in lines:
                l["_src"] = "ocr"
        else:
            lines = [{"text": l, "_src": "text"} for l in text.splitlines() if l.strip() and not l.startswith("--- page")]
        cache_put(pdf, lines)

    path = pdf.relative_to(folder).as_posix()
    return material(type_name, pdf.name, str(folder), path, lines)


def show_material(mat: dict) -> None:
    print("\n" + "=" * 70)
    print(f"FILE: {mat['file']}  (type: {mat['type']})")
    print(f"PATH: {mat['path']}")
    print("-" * 70)
    cand = mat.get("candidati", {})
    tot = sum(len(v) for v in cand.values())
    summary = ", ".join(f"{k}: {len(v)}" for k, v in sorted(cand.items()) if v)
    print(f"CANDIDATI ({tot}): {summary}")
    print(f"RIGHE: {len(mat.get('lines', []))}")
    print("=" * 70)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder", type=Path)
    ap.add_argument("--type", required=True,
                    help="Tipo documento (routing, vedi config/collections.yml). Es. Assicurazioni, Veicoli.")
    ap.add_argument("--material", type=Path, default=None,
                    help="Cartella dove salvare i JSON di materiale (per l'interpretazione del modello).")
    ap.add_argument("--limit", type=int, default=0, help="Limita a N file (per test)")
    ap.add_argument("--subdirs", nargs="*", default=None,
                    help="Filtra per sottocartelle (es. Tagliandi Bolli Revisioni). Default: tutte.")
    args = ap.parse_args()

    print(f"Tipo: {args.type}\n")

    pdfs = sorted(args.folder.rglob("*.pdf")) + sorted(args.folder.rglob("*.PDF"))
    if args.subdirs:
        pdfs = [p for p in pdfs if any(s in p.parts for s in args.subdirs)]
    if args.limit:
        pdfs = pdfs[:args.limit]
    print(f"Trovati {len(pdfs)} PDF in {args.folder}\n")

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        results = []
        for i, pdf in enumerate(pdfs, 1):
            print(f"[{i}/{len(pdfs)}] {pdf.name}")
            try:
                mat = process_pdf(args.type, pdf, args.folder, tmp)
            except Exception as e:
                print(f"  ERRORE: {e}")
                continue
            show_material(mat)
            results.append(mat)

        print(f"\nRiepilogo: {len(results)} file con materiale.")

        if args.material:
            args.material.mkdir(parents=True, exist_ok=True)
            for i, mat in enumerate(results, 1):
                out = args.material / f"{i:03d}.json"
                with open(out, "w") as f:
                    json.dump(mat, f, ensure_ascii=False, indent=2)
            print(f"Materiale salvato in {args.material}")
            print("\nOra interpreta il materiale (compila i record secondo lo schema),")
            print("valida con ingest_to_mongo.py --dry-run e importa con --yes.")


if __name__ == "__main__":
    main()
