"""Primitivi di estrazione generici — decontestualizzati, per qualunque tipo documento.

Ogni funzione ritorna CANDIDATI (Hit) con valore normalizzato ed esatto, ricavati
dalle righe text-layer/OCR (senza alcuna logica di prodotto o layout). Il modello
(l'agente) sceglie quale candidato è quello giusto per il documento leggendo il
contesto: non deve trascrivere cifre a mano, perché i valori qui sono già esatti.

Uso tipico (pipeline generica):
    from extractor import material, candidati
    mat = material(type_name, pdf.name, str(folder), relative_path, lines)
    # -> {"file", "folder", "path", "type", "lines", "candidati"}

Le funzioni non interpretano il significato (quale data è la scadenza? quale
importo è il totale?): è compito del modello scegliere per contesto.
"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from datetime import datetime


@dataclass
class Hit:
    value: str | float | int | None
    raw: str
    start: int
    end: int
    note: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


_MESI = {
    "gennaio": 1, "febbraio": 2, "marzo": 3, "aprile": 4, "maggio": 5, "giugno": 6,
    "luglio": 7, "agosto": 8, "settembre": 9, "ottobre": 10, "novembre": 11, "dicembre": 12,
}


# ---------- Date ----------

_DATE_SEP = re.compile(r"(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})")
_DATE_ITA = re.compile(r"(\d{1,2})\s+([A-Za-zÀ-ù]+)\s+(\d{4})")


def _iso(d: int, m: int, y: int) -> str | None:
    try:
        return datetime(y, m, d).date().isoformat()
    except ValueError:
        return None


def dates(text: str) -> list[Hit]:
    """Date in formato numerico (DD/MM/YYYY, DD-MM-YYYY, DD.MM.YYYY) o italiano
    (DD mese YYYY). Valore normalizzato ISO 8601 (YYYY-MM-DD)."""
    out = []
    for m in _DATE_SEP.finditer(text):
        iso = _iso(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        if iso:
            out.append(Hit(iso, m.group(0), m.start(), m.end(), "data numerica"))
    for m in _DATE_ITA.finditer(text):
        mo = _MESI.get(m.group(2).strip().lower())
        if mo:
            iso = _iso(int(m.group(1)), mo, int(m.group(3)))
            if iso:
                out.append(Hit(iso, m.group(0), m.start(), m.end(), "data italiana"))
    return out


# ---------- Importi ----------

_AMOUNT_RE = re.compile(
    r"(?:€|EUR|euro\b)\s*(\d[\d.,]*)"
    r"|(\d{1,3}(?:\.\d{3})+(?:,\d{2})?)\s*(?:€|EUR|euro\b)"
    r"|(\d{1,3}(?:\.\d{3})+(?:,\d{2})?)"
    r"|(\d{1,3},\d{2})(?![\d,])"
    r"|(\d+\.\d{2})(?![\d.])"
)


def _to_float_amt(s: str) -> float | None:
    """Normalizza un importo italiano/decimale a float."""
    s = s.strip()
    if not s or not re.search(r"\d", s):
        return None
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    elif "." in s:
        # Separatore migliaia ("1.000", "6.450.000") vs decimale ("1234.56"):
        # migliaia se più punti, oppure un solo punto seguito da 3 cifre.
        if s.count(".") > 1 or (len(s) - s.rfind(".") - 1) == 3:
            s = s.replace(".", "")
    try:
        return float(s)
    except ValueError:
        return None


def amounts(text: str) -> list[Hit]:
    """Importi in euro: '€ 1.234,56', '1.234,56', '425,00', '1234.56', '6.450.000'.
    Valore normalizzato float (1253385.94). Rileva solo valori con simbolo valuta,
    separatore delle migliaia o decimali espliciti (riduce i falsi positivi)."""
    out = []
    for m in _AMOUNT_RE.finditer(text):
        raw = next((g for g in m.groups() if g is not None), None)
        if raw is None:
            continue
        v = _to_float_amt(raw)
        if v is None:
            continue
        out.append(Hit(v, m.group(0), m.start(), m.end(), "importo"))
    return out


# ---------- Targhe e telaio ----------

_PLATE_RE = re.compile(r"\b[A-Z]{2}\d{3,5}[A-Z]{0,2}\b")
_VIN_RE = re.compile(r"\b[A-HJ-NPR-Z0-9]{17}\b")


def plates(text: str) -> list[Hit]:
    """Targhe italiane: formato attuale AA123AB e vecchio AA12345."""
    return [Hit(m.group(0), m.group(0), m.start(), m.end(), "targa IT") for m in _PLATE_RE.finditer(text)]


def vins(text: str) -> list[Hit]:
    """Numeri di telaio/VIN (17 caratteri, no I/O/Q)."""
    return [Hit(m.group(0), m.group(0), m.start(), m.end(), "VIN/telaio") for m in _VIN_RE.finditer(text)]


# ---------- Codici fiscali ----------

_CF_RE = re.compile(r"\b[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]\b")


def codici_fiscali(text: str) -> list[Hit]:
    """Codici fiscali italiani (16 caratteri)."""
    return [Hit(m.group(0), m.group(0), m.start(), m.end(), "codice fiscale IT") for m in _CF_RE.finditer(text)]


# ---------- IBAN ----------

_IBAN_RE = re.compile(r"\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b")


def ibans(text: str) -> list[Hit]:
    """IBAN: IT (27 caratteri) o generico."""
    out = []
    for m in _IBAN_RE.finditer(text):
        v = m.group(0)
        note = "IBAN IT" if v.upper().startswith("IT") and len(v) == 27 else "IBAN"
        out.append(Hit(v, v, m.start(), m.end(), note))
    return out


# ---------- Telefoni ----------

_PHONE_RE = re.compile(
    r"\b(?:\+39[\s\-]?\d{6,10}|3\d{2}[\s\-]\d{6,7}|0\d{1,3}[\s\-]\d{5,8}|800[\s\-]?\d{3}\s?\d{3})\b"
)


def telefoni(text: str) -> list[Hit]:
    """Numeri di telefono italiani (fisso/mobile/verde), senza spazi nel valore."""
    out = []
    for m in _PHONE_RE.finditer(text):
        out.append(Hit(re.sub(r"[\s\-]", "", m.group(0)), m.group(0), m.start(), m.end(), "telefono IT"))
    return out


# ---------- Percentuali ----------

_PERC_RE = re.compile(r"(\d{1,2}(?:[.,]\d{1,2})?)\s*%")


def percentuali(text: str) -> list[Hit]:
    """Percentuali (es. scoperti 20%). Valore float (20.0)."""
    out = []
    for m in _PERC_RE.finditer(text):
        v = _to_float_amt(m.group(1))
        if v is not None:
            out.append(Hit(v, m.group(0), m.start(), m.end(), "percentuale"))
    return out


# ---------- Numeri interi ----------

_INT_RE = re.compile(r"\b\d{2,5}\b")
_SEQ_RE = re.compile(r"\b\d{6,}\b")


def interi(text: str) -> list[Hit]:
    """Numeri interi 2-5 cifre (km, anni, quantità...). Include gli anni delle date."""
    return [Hit(int(m.group(0)), m.group(0), m.start(), m.end(), "intero") for m in _INT_RE.finditer(text)]


def sequenze_numeriche(text: str) -> list[Hit]:
    """Sequenze numeriche di 6+ cifre (numeri polizza, documenti, transazioni)."""
    return [Hit(m.group(0), m.group(0), m.start(), m.end(), "sequenza numerica") for m in _SEQ_RE.finditer(text)]


# ---------- Bundle ----------

def candidati(text: str) -> dict[str, list[dict]]:
    """Tutti i candidati per un testo, in formato serializzabile."""
    return {
        "date": [h.to_dict() for h in dates(text)],
        "importi": [h.to_dict() for h in amounts(text)],
        "targhe": [h.to_dict() for h in plates(text)],
        "telaio": [h.to_dict() for h in vins(text)],
        "codici_fiscali": [h.to_dict() for h in codici_fiscali(text)],
        "iban": [h.to_dict() for h in ibans(text)],
        "telefoni": [h.to_dict() for h in telefoni(text)],
        "percentuali": [h.to_dict() for h in percentuali(text)],
        "interi": [h.to_dict() for h in interi(text)],
        "sequenze_numeriche": [h.to_dict() for h in sequenze_numeriche(text)],
    }


def material(type_name: str, filename: str, folder: str, path: str, lines: list[dict]) -> dict:
    """Materiale agnostico su cui il MODELLO compila il record.

    Solo dati di contesto: cartella scansionata, righe text-layer/OCR e candidati
    esatti dei primitivi. Nessuna classificazione, nessuno skip, nessuna logica
    per-prodotto: tutto il resto (forma_documento, tipo_soggetto, tipo_intervento,
    skip) lo decide il modello leggendo `lines`, `folder` e `path` secondo le regole
    di SKILL.md (§7) e lo schema.

    `folder` può contenere path personali: è materiale transitorio (mai committato
    né scritto nell'archivio), usato solo per l'interpretazione.
    """
    full = "\n".join(l["text"] for l in lines)
    return {
        "file": filename,
        "folder": folder,
        "path": path,
        "type": type_name,
        "lines": [
            {"page": l.get("page"), "y": l.get("y"), "x": l.get("x"), "text": l["text"]}
            for l in lines
        ],
        "candidati": candidati(full),
    }
