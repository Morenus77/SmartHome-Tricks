import PDFKit
import Foundation
let url = URL(fileURLWithPath: CommandLine.arguments[1])
guard let doc = PDFDocument(url: url) else { print("NO_DOC"); exit(1) }
for i in 0..<doc.pageCount {
    if let text = doc.page(at: i)?.string {
        print("--- page \(i+1) ---")
        print(text)
    }
}
