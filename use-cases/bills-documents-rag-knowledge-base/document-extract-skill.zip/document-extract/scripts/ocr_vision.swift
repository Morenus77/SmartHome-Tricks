import Vision
import AppKit
import Foundation

let path = CommandLine.arguments[1]
guard let img = NSImage(contentsOfFile: path),
      let tiff = img.tiffRepresentation,
      let rep = NSBitmapImageRep(data: tiff),
      let cg = rep.cgImage else { print("NO_IMG"); exit(1) }

let request = VNRecognizeTextRequest()
request.recognitionLevel = .accurate
request.recognitionLanguages = ["it-IT", "en-US"]
request.usesLanguageCorrection = true

let handler = VNImageRequestHandler(cgImage: cg, options: [:])
try handler.perform([request])

guard let obs = request.results else { exit(0) }
for o in obs {
    if let top = o.topCandidates(1).first {
        let b = o.boundingBox
        print(String(format: "[y=%.3f x=%.3f] %@", 1 - b.origin.y - b.height, b.origin.x, top.string))
    }
}
