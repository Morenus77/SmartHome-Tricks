#!/usr/bin/env python3
"""
ingest_groups.py — Raggruppa PDF per data (prefisso YYYYMMDD nel nome) e salva
il testo combinato (text-layer o OCR) per gruppo. Un gruppo = un evento/intervento.

Uso:
    python3 ingest_groups.py <cartella> <outdir>

Output: <outdir>/<YYYYMMDD>.txt  (righe con [page=n|y=|x=] per il riconoscimento layout)
"""

import re
import subprocess
import sys
import tempfile
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
SCRIPTS = SKILL_DIR / "scripts"


def text_layer(pdf: Path) -> str:
    return subprocess.run(["swift", str(SCRIPTS / "pdf_to_text.swift"), str(pdf)],
                          capture_output=True, text=True).stdout


def ocr_pdf(pdf: Path, outdir: Path) -> str:
    subprocess.run(["swift", str(SCRIPTS / "pdf_to_pages.swift"), str(pdf), str(outdir)],
                   capture_output=True, text=True)
    out = []
    for png in sorted(outdir.glob("page*.png")):
        res = subprocess.run(["swift", str(SCRIPTS / "ocr_vision.swift"), str(png)],
                             capture_output=True, text=True).stdout
        for row in res.splitlines():
            m = re.match(r"\[y=([\d.]+) x=([\d.]+)\] (.*)", row)
            if m:
                out.append(f"[p={png.stem.replace('page','')} y={m.group(1)} x={m.group(2)}] {m.group(3)}")
    return "\n".join(out)


def main():
    folder = Path(sys.argv[1])
    outdir = Path(sys.argv[2])
    outdir.mkdir(parents=True, exist_ok=True)

    pdfs = sorted(folder.glob("*.pdf")) + sorted(folder.glob("*.PDF"))
    groups = {}
    for pdf in pdfs:
        m = re.match(r"^(\d{8})", pdf.name)
        if m:
            groups.setdefault(m.group(1), []).append(pdf)
        else:
            groups.setdefault("nndata", []).append(pdf)

    with tempfile.TemporaryDirectory() as tmp:
        for date, files in sorted(groups.items()):
            print(f"\n=== {date} ({len(files)} file) ===")
            parts = []
            for pdf in files:
                print(f"  {pdf.name}")
                text = text_layer(pdf)
                if text.strip():
                    parts.append(f"\n########## FILE: {pdf.name} ##########\n" + text)
                else:
                    workdir = Path(tmp) / f"{date}_{pdf.stem}"
                    workdir.mkdir(parents=True, exist_ok=True)
                    ocr = ocr_pdf(pdf, workdir)
                    parts.append(f"\n########## FILE: {pdf.name} ##########\n" + ocr)
            combined = "\n".join(parts)
            out = outdir / f"{date}.txt"
            out.write_text(combined)
            print(f"  -> {out.name} ({len(combined)} caratteri)")


if __name__ == "__main__":
    main()
