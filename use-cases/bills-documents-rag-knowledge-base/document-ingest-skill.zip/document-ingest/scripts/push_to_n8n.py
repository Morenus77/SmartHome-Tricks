#!/usr/bin/env python3
"""
push_to_n8n.py — Invio di un singolo record da Mongo al webhook n8n (mode: Ingest).

Uso (dopo che document-extract ha scritto il record in Mongo):
    .venv/bin/python3 scripts/push_to_n8n.py <id_mongo>
    .venv/bin/python3 scripts/push_to_n8n.py '{"targa": "AA000AA", "data_intervento": "2026-05-06"}'
    .venv/bin/python3 scripts/push_to_n8n.py <id_mongo> --type Veicoli   # forza il type
    .venv/bin/python3 scripts/push_to_n8n.py <id_mongo> --dry-run        # mostra il payload senza inviare

L'identificativo è un _id Mongo (stringa hex) oppure un filtro JSON (primo match).
Il type si ricava dal record (campo `type`); se assente si passa con --type.
Successo = HTTP 2xx E body con i documenti Qdrant (vedi has_qdrant_content in rebuild_qdrant.py).
Richiede in ambiente: MONGO_URI, N8N_INGESTURL, N8N_API_KEY (vedi .env della skill).
"""

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    from pymongo import MongoClient
except ImportError as e:
    sys.exit(f"Dipendenza mancante: {e}\nInstalla con: .venv/bin/pip install pymongo")

from rebuild_qdrant import build_headers, build_payload, load_config, send_payload


def _is_object_id(ident: str) -> bool:
    return len(ident) == 24 and all(c in "0123456789abcdefABCDEF" for c in ident)


def find_record(client, ident: str):
    """Cerca il record nelle collection configurate. ident = _id hex oppure filtro JSON."""
    from bson.objectid import ObjectId

    config = load_config()
    for type_name, cfg in config.get("types", {}).items():
        db = client[cfg["db"]]
        for col in cfg.get("collections", []):
            if _is_object_id(ident):
                try:
                    query = {"_id": ObjectId(ident)}
                except Exception:
                    continue
            else:
                try:
                    query = json.loads(ident)
                except (ValueError, TypeError):
                    sys.exit(f"Identificativo non valido: '{ident}' (atteso _id hex o filtro JSON)")
            rec = db[col].find_one(query)
            if rec is not None:
                return rec, type_name
    sys.exit(f"Nessun record trovato con '{ident}' nelle collection configurate.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ident", help="_id Mongo (hex) oppure filtro JSON per trovare il record")
    ap.add_argument("--type", help="Forza il type (se assente nel record)")
    ap.add_argument("--mode", default="Ingest",
                    help="Mode verso n8n (default: Ingest, l'unico supportato dal workflow)")
    ap.add_argument("--dry-run", action="store_true", help="Mostra il payload senza inviare")
    args = ap.parse_args()

    uri = os.environ.get("MONGO_URI")
    url = os.environ.get("N8N_INGESTURL")
    api_key = os.environ.get("N8N_API_KEY", "")
    if not uri or not url:
        sys.exit("MONGO_URI e N8N_INGESTURL devono essere esportate (vedi .env della skill).")

    client = MongoClient(uri, serverSelectionTimeoutMS=5000)
    client.admin.command("ping")

    rec, coll_type = find_record(client, args.ident)
    type_name = rec.get("type") or args.type or coll_type
    if not type_name:
        sys.exit("Type non determinabile: passa --type.")

    payload = build_payload(rec, type_name, args.mode)
    print(json.dumps(payload, ensure_ascii=False, indent=2, default=str))

    if args.dry_run:
        print("\nDRY-RUN: nessuna richiesta inviata.")
        return

    ok, reason = send_payload(url, payload, build_headers(api_key))
    if not ok:
        sys.exit(f"Ingest fallito: {reason}")
    print("\nIngest OK (punto verificato nel body della risposta).")


if __name__ == "__main__":
    main()
