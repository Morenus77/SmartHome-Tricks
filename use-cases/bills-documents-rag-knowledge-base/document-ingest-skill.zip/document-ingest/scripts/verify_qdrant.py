#!/usr/bin/env python3
"""
verify_qdrant.py — Verifica read-only che un record sia nel vector store (Qdrant).

Dopo un ingest (push_to_n8n.py / rebuild_qdrant.py), conferma che il punto esista
in Qdrant interrogandolo DIRETTAMENTE (solo LETTURA: points/scroll con filtro sul
metadata.id Mongo). Questa è l'unica interazione che questa skill ha con Qdrant:
le scritture passano esclusivamente dal webhook n8n del workflow "Documenti RAG".

Serve in ambiente QADRANT_URL e QADRANT_API_KEY (vedi .env della skill). Senza
api-key, un Qdrant con autenticazione attiva risponde 403.

Uso:
    python3 verify_qdrant.py <id_mongo>           # verifica un punto per metadata.id
    python3 verify_qdrant.py --id <id>            # forma esplicita
    python3 verify_qdrant.py --type Veicoli       # verifica per metadata.type (più punti)
    python3 verify_qdrant.py --collection Documenti
"""

import argparse
import json
import os
import sys
import urllib.request
import urllib.error

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
)
AUTH_HEADER = "api-key"
MAX_ATTEMPTS = 3


def scroll(url: str, collection: str, payload: dict, api_key: str) -> tuple[bool, str, dict]:
    """points/scroll read-only. Ritorna (ok, motivo, body_json)."""
    data = json.dumps(payload).encode("utf-8")
    headers = {"Content-Type": "application/json", "User-Agent": USER_AGENT}
    if api_key:
        headers[AUTH_HEADER] = api_key
    req = urllib.request.Request(
        f"{url}/collections/{collection}/points/scroll", data=data, headers=headers, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            return True, "", json.loads(body) if body else {}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        if e.code == 403:
            return False, "403: autenticazione Qdrant (api-key) mancante o errata", {}
        return False, f"HTTP {e.code}: {body[:200]}", {}
    except urllib.error.URLError as e:
        return False, f"Errore rete: {e}", {}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("id", nargs="?", default=None, help="_id Mongo del record da verificare")
    ap.add_argument("--id", dest="id_opt", default=None, help="_id Mongo (forma esplicita)")
    ap.add_argument("--type", default=None, help="Filtra per metadata.type (es. Veicoli)")
    ap.add_argument("--collection", default="Documenti", help="Collection Qdrant (default: Documenti)")
    ap.add_argument("--limit", type=int, default=5, help="Punti da mostrare (default: 5)")
    args = ap.parse_args()

    url = os.environ.get("QADRANT_URL", "").rstrip("/")
    api_key = os.environ.get("QADRANT_API_KEY", "")
    if not url:
        sys.exit("QADRANT_URL deve essere esportata (vedi .env della skill).")

    rec_id = args.id or args.id_opt
    if not rec_id and not args.type:
        sys.exit("Serve un id Mongo o --type.")

    must = []
    if rec_id:
        must.append({"key": "metadata.id", "match": {"value": rec_id}})
    if args.type:
        must.append({"key": "metadata.type", "match": {"value": args.type}})
    payload = {"limit": args.limit, "with_payload": True, "filter": {"must": must}}

    print(f"Qdrant: {url}  collection: {args.collection}  filtro: {json.dumps(must)}")
    ok, reason, data = scroll(url, args.collection, payload, api_key)
    if not ok:
        sys.exit(f"Verifica fallita — {reason}")

    points = data.get("result", {}).get("points", [])
    if not points:
        print("Nessun punto trovato: il record NON è in Qdrant.")
        sys.exit(1)

    print(f"{len(points)} punto/i trovato/i:")
    for p in points:
        pid = p.get("id")
        payload_doc = p.get("payload", {})
        md = payload_doc.get("metadata", {})
        text = payload_doc.get("pageContent") or payload_doc.get("content") or ""
        print(f"\n- point_id: {pid}")
        print(f"  type:     {md.get('type')} | id: {md.get('id')} | fornitore: {md.get('fornitore')} | targa: {md.get('targa')} | data: {md.get('data')}")
        snippet = " ".join(text.split())[:180]
        print(f"  content:  {snippet}{'...' if len(text) > 180 else ''}")
    sys.exit(0)


if __name__ == "__main__":
    main()
