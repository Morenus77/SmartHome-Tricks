#!/usr/bin/env python3
"""
rebuild_qdrant.py — Reingestione (re-index) da MongoDB → Qdrant via n8n.

L'archivio canonico è Mongo, Qdrant è l'indice ricostruibile. Questo script
rilegge i record da Mongo e li invia al webhook n8n del workflow
"Documenti RAG" con mode: Ingest (l'unico mode supportato), che fa
embed + insert in Qdrant. La deduplica NON è un upsert su point ID (il nodo
Qdrant è mode: insert): ri-inviare lo stesso record non crea duplicati perché
il workflow, prima dell'insert, cancella i punti con metadata.id = $json.id
(nodo "Safe delete previous version"). Mai ri-OCR.

Payload per type (vedi build_payload):
- Type con workflow dedicato n8n (Bollette/Pedaggi): record crudo + id/type/mode
  + metadata = record Mongo completo + id/type/mode (il normalizer/loader di n8n
  legge i campi da $json.metadata: senza, il contenuto esce pieno di "undefined").
- Type gestiti da questo skill (schema con pageContent_template, es. Veicoli):
  {id, type, mode, pageContent, metadata} — pageContent dal template dello schema,
  metadata = record Mongo completo + id/type/mode.

In entrambi i casi `id` = _id Mongo (stringa) al top livello, e `type`/`mode`
anche dentro `metadata`. Il loader del workflow persiste in Qdrant i facet che
mappa da $json.metadata.*.

VERIFICA: il webhook risponde 200 anche quando l'ingest fallisce. Il successo
si valuta sul BODY della risposta, che deve contenere i documenti Qdrant
(JSON array con content/pageContent). Body vuoto o senza contenuto = ingest
fallito (es. branch del type non cablato nel workflow) — lo script lo segna
come FAIL.

Webhook: richiede header `n8n-api-key: <N8N_API_KEY>` e un User-Agent da browser
(il dominio è dietro Cloudflare, che blocca gli UA di default di urllib).
Vedi SKILL.md §4/§6 e .env.

Uso:
    python3 rebuild_qdrant.py                     # re-ingest (tutti i type configurati)
    python3 rebuild_qdrant.py --db Bollette       # solo un DB Mongo
    python3 rebuild_qdrant.py --types Bollette    # solo alcuni type
    python3 rebuild_qdrant.py --limit 2           # test: primi N record per collection
    python3 rebuild_qdrant.py --dry-run           # mostra cosa invierebbe senza inviare
    python3 rebuild_qdrant.py --yes               # salta la conferma
"""

import argparse
import json
import os
import re
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

try:
    import yaml
    from pymongo import MongoClient
except ImportError as e:
    sys.exit(f"Dipendenza mancante: {e}\nInstalla con: .venv/bin/pip install pymongo pyyaml")

SKILL_DIR = Path(__file__).resolve().parent.parent            # questa skill (document-ingest)
BASE_SKILL_DIR = SKILL_DIR.parent / "document-extract"        # skill base (sibling): unica fonte di config/schemi
CONFIG_FILE = BASE_SKILL_DIR / "config" / "collections.yml"
SCHEMAS_DIR = BASE_SKILL_DIR / "schemas"

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
)
AUTH_HEADER = "n8n-api-key"
MAX_ATTEMPTS = 3


def load_config() -> dict:
    if not CONFIG_FILE.exists():
        sys.exit(
            "Config non trovata: skill base 'document-extract' assente. "
            "Installa document-extract come sibling di document-ingest "
            "(~/.claude/skills/document-extract/)."
        )
    with open(CONFIG_FILE) as f:
        return yaml.safe_load(f)


def build_headers(api_key: str) -> dict:
    headers = {"Content-Type": "application/json", "User-Agent": USER_AGENT}
    if api_key:
        headers[AUTH_HEADER] = api_key
    return headers


def load_schema(type_name: str) -> dict:
    """Schema del type (dalla skill base document-extract, schemas/<type>.json),
    o {} se non esiste (es. Bollette/Pedaggi, gestiti da n8n)."""
    f = SCHEMAS_DIR / f"{type_name}.json"
    if not f.exists():
        f = SCHEMAS_DIR / f"{type_name.lower()}.json"
    if not f.exists():
        return {}
    with open(f) as fh:
        return json.load(fh)


def format_voci(voci) -> str:
    if not isinstance(voci, list):
        return ""
    lines = []
    for v in voci:
        if not isinstance(v, dict):
            continue
        parts = []
        if v.get("descrizione"):
            parts.append(str(v["descrizione"]))
        if v.get("quantita"):
            parts.append(f"x{v['quantita']:g}")
        if v.get("importo") is not None:
            parts.append(f"€ {v['importo']:g}")
        if parts:
            lines.append(" - ".join(parts))
    return "\n".join(lines)


def format_componenti(componenti) -> str:
    if not isinstance(componenti, list):
        return ""
    lines = []
    for c in componenti:
        if not isinstance(c, dict):
            continue
        parts = []
        if c.get("ambito"):
            parts.append(str(c["ambito"]))
        if c.get("soluzione"):
            parts.append(f"({c['soluzione']})")
        if c.get("numero"):
            parts.append(f"n. {c['numero']}")
        if c.get("premio") is not None:
            parts.append(f"€ {c['premio']:g}")
        g = c.get("garanzie")
        if isinstance(g, list) and g:
            names = []
            for gg in g:
                if isinstance(gg, dict) and gg.get("garanzia"):
                    names.append(str(gg["garanzia"]))
            if names:
                parts.append("garanzie: " + ", ".join(names))
        if parts:
            lines.append(" - ".join(parts))
    return "\n".join(lines)


def _get_path(rec: dict, key: str):
    """Accesso annidato con dot-path (es. 'premio.totale')."""
    cur = rec
    for part in key.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def render_template(template: str, rec: dict) -> str:
    """Compila il template pageContent dello schema con i campi del record.

    Supporta placeholder annidati con dot-path (es. {premio.totale}) e i
    formattatori speciali {voci_formatted} e {componenti_formatted}.
    I campi assenti restano vuoti; le righe senza valore vengono scartate."""
    repl = {}
    for key in re.findall(r"\{([\w.]+)\}", template):
        if key == "voci_formatted":
            repl[key] = format_voci(rec.get("voci"))
            continue
        if key == "componenti_formatted":
            repl[key] = format_componenti(rec.get("componenti"))
            continue
        v = _get_path(rec, key)
        if isinstance(v, bool):
            repl[key] = "si" if v else "no"
        elif isinstance(v, (int, float)):
            repl[key] = f"{v:g}"
        elif isinstance(v, list):
            repl[key] = ", ".join(str(x) for x in v)
        elif isinstance(v, dict):
            repl[key] = json.dumps(v, ensure_ascii=False)
        else:
            repl[key] = str(v) if v is not None else ""
    text = template
    for k, v in repl.items():
        text = text.replace("{" + k + "}", v)
    lines = []
    for line in text.splitlines():
        line = line.rstrip()
        if not line.strip():
            continue
        if re.match(r"^[A-Za-zÀ-ÿ /]+:\s*$", line):
            continue
        lines.append(line)
    return "\n".join(lines)


def build_payload(rec: dict, type_name: str, mode: str) -> dict:
    """Payload verso il webhook n8n, dipendente dal type.

    - Type con workflow dedicato n8n (Bollette/Pedaggi): il record crudo con
      id, type e mode al top, più metadata = record Mongo completo + id/type/mode
      (il workflow costruisce il contenuto leggendo i campi da $json.metadata:
      senza il record in metadata l'output esce pieno di "undefined").
    - Type gestiti da questo skill (es. Veicoli, schema con pageContent_template):
      {id, type, mode, pageContent, metadata} — pageContent dal template dello schema,
      metadata = record Mongo completo con id, type e mode.

    In entrambi i casi `type` e `mode` sono anche dentro `metadata`, per coerenza
    col modello delle bollette; `id` (l'_id Mongo, stringa) è la chiave stabile e
    univoca usata dal nodo di delete in n8n per evitare duplicati."""
    schema = load_schema(type_name)
    template = schema.get("pageContent_template") if isinstance(schema, dict) else None
    rec_id = str(rec.get("_id") or "")
    if template:
        metadata = dict(rec)
        metadata["id"] = rec_id
        metadata["type"] = type_name
        metadata["mode"] = mode
        return {
            "id": rec_id,
            "type": type_name,
            "mode": mode,
            "pageContent": render_template(template, rec),
            "metadata": metadata,
        }
    return {
        **rec,
        "id": rec_id,
        "type": type_name,
        "mode": mode,
        "metadata": {**rec, "id": rec_id, "type": type_name, "mode": mode},
    }


def has_qdrant_content(body: str) -> bool:
    """True se il body è la risposta di ingest: JSON array con almeno un documento
    con contenuto testuale. Il workflow n8n salva il testo nel campo `content`
    (i type gestiti da n8n), i type generati dallo skill usano `pageContent`."""
    try:
        data = json.loads(body)
    except (ValueError, TypeError):
        return False
    if not isinstance(data, list):
        return False
    for d in data:
        if not isinstance(d, dict):
            continue
        text = d.get("content") or d.get("pageContent")
        if isinstance(text, str) and text.strip():
            return True
    return False


def send_payload(url: str, payload: dict, headers: dict) -> tuple[bool, str]:
    """Invia un record al webhook n8n con retry.

    Successo = HTTP 2xx E body con i documenti Qdrant (campo content/pageContent).
    HTTP 200 con body vuoto/senza contenuto = ingest fallito.
    Ritorna (ok, motivo)."""
    data = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
    for attempt in range(1, MAX_ATTEMPTS + 1):
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                body = resp.read().decode("utf-8", errors="replace")
                if resp.status in (200, 201, 204) and has_qdrant_content(body):
                    return True, ""
                reason = f"HTTP {resp.status}, body senza documenti Qdrant"
                if body.strip():
                    reason += f": {body[:200]}"
                return False, reason
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            print(f"    !! HTTP {e.code}: {body[:200]}")
        except urllib.error.URLError as e:
            print(f"    !! Errore rete: {e}")
        except Exception as e:
            print(f"    !! Errore: {e}")
        if attempt < MAX_ATTEMPTS:
            wait = 2 ** (attempt - 1)
            print(f"    retry in {wait}s...")
            time.sleep(wait)
    return False, "troppi retry"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", action="append", default=None,
                    help="DB Mongo (default: tutti i DB dei type configurati)")
    ap.add_argument("--types", nargs="*", default=None,
                    help="Solo questi type (default: tutti)")
    ap.add_argument("--mode", default="Ingest",
                    help="Mode verso n8n (default: Ingest, l'unico supportato dal workflow)")
    ap.add_argument("--dry-run", action="store_true", help="Mostra cosa invierebbe senza inviare")
    ap.add_argument("--limit", type=int, default=0, help="Test: primi N record per collection")
    ap.add_argument("--yes", "-y", action="store_true", help="Salta la conferma finale")
    args = ap.parse_args()

    config = load_config()
    type_cfgs = config.get("types", {})
    if args.types:
        type_cfgs = {t: type_cfgs[t] for t in args.types if t in type_cfgs}
        missing = [t for t in args.types if t not in type_cfgs]
        if missing:
            sys.exit(f"Type non configurati: {missing}. Config: {list(config['types'])}")

    dbs = args.db or sorted({cfg["db"] for cfg in type_cfgs.values()})

    uri = os.environ.get("MONGO_URI")
    url = os.environ.get("N8N_INGESTURL")
    api_key = os.environ.get("N8N_API_KEY", "")
    if not uri or not url:
        sys.exit("MONGO_URI e N8N_INGESTURL devono essere esportate (vedi .env della skill).")

    headers = build_headers(api_key)
    client = MongoClient(uri, serverSelectionTimeoutMS=5000)
    client.admin.command("ping")

    print(f"Webhook: {url}  (auth: header '{AUTH_HEADER}')")
    print(f"DB:      {', '.join(dbs)}  |  mode: {args.mode}")
    if args.dry_run:
        print("Modalità DRY-RUN: nessuna richiesta inviata.\n")

    # Costruisci l'elenco (db, collection, type_name, n) per conferma e conteggi
    plan: list[tuple[str, str, str, int]] = []
    for db_name in dbs:
        db = client[db_name]
        for col in sorted(db.list_collection_names()):
            matches = [t for t, cfg in type_cfgs.items()
                       if cfg.get("db") == db_name and col in cfg.get("collections", [])]
            if not matches:
                continue
            type_name = matches[0]
            if len(matches) > 1:
                print(f"  [info] {col}: più type configurati, uso '{type_name}'")
            n = db[col].count_documents({})
            plan.append((db_name, col, type_name, n))

    if not plan:
        sys.exit("Nessuna collection da processare con la selezione data.")

    total = sum(n for _, _, _, n in plan)
    print(f"\nPiano: {len(plan)} collection, {total} record.")
    for db_name, col, type_name, n in plan:
        print(f"  - {db_name}.{col} ({type_name}): {n}")

    if not args.dry_run and not args.limit and not args.yes:
        resp = input(f"\nProcedere con il ri-ingest di {total} record in Qdrant (mode {args.mode})? [s/N]: ").strip().lower()
        if resp != "s":
            print("Annullato.")
            return

    totals: dict[str, dict[str, int]] = {}
    for db_name, col, type_name, n_total in plan:
        coll = client[db_name][col]
        cursor = coll.find({})
        if args.limit:
            cursor = cursor.limit(args.limit)

        n_ok = n_fail = 0
        if args.dry_run:
            for rec in cursor:
                payload = build_payload(rec, type_name, args.mode)
                if n_ok < 1:
                    print(f"  {type_name}/{col}: {json.dumps(payload, ensure_ascii=False, default=str)}")
                n_ok += 1
        else:
            for rec in cursor:
                payload = build_payload(rec, type_name, args.mode)
                ok, reason = send_payload(url, payload, headers)
                if ok:
                    n_ok += 1
                else:
                    n_fail += 1
                    print(f"  FAIL {type_name}/{col} {rec.get('_id')} — {reason}")
            time.sleep(0.05)  # non sovraccaricare n8n (embed OpenAI)

        n_proc = n_ok + n_fail
        label = "DRY-RUN" if args.dry_run else f"ok={n_ok} fail={n_fail}"
        suffix = f" (di {n_total}, limit {args.limit})" if args.limit and n_total > n_proc else f" (di {n_total})"
        print(f"  ✓ {col}: {label}{suffix}")

        totals.setdefault(type_name, {"ok": 0, "fail": 0})
        totals[type_name]["ok"] += n_ok
        totals[type_name]["fail"] += n_fail

    print("\n=== RIEPILOGO ===")
    for t, s in totals.items():
        print(f"  {t}: ok={s['ok']} fail={s['fail']}")
    fails = sum(s["fail"] for s in totals.values())
    print("Fatto." if fails == 0 else f"Fatto con {fails} errori (vedi sopra).")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
