---
name: document-ingest
description: Extension skill for ingesting documents into the personal RAG knowledge base (MongoDB + Qdrant).
Extends document-extract: data extraction and MongoDB writes are done by the base skill; this one adds the push to the n8n "Documenti RAG" webhook (mode: Ingest) and the Qdrant verification.
Use ALWAYS when the user asks to save documents to the RAG knowledge base, run an ingest/re-ingest in Qdrant, or when the full flow is required (PDF → extraction → Mongo → Qdrant).
---

# Skill: Document Ingest — extension of document-extract (RAG ingest via n8n)

## 0. Context

This skill is the **extension** of the **`document-extract`** skill (sibling folder `~/.claude/skills/document-extract/`). The base skill does: text layer/OCR → structured extraction → validation → save to **MongoDB** (the canonical archive). This extension adds the second stage: **the ingest into the vector store**.

The documents feed a personal RAG knowledge base on **MongoDB** (canonical archive) + **Qdrant** (vector index, collection `Documenti`). The n8n workflow **"Documenti RAG"** is **the only ingest point into the vector store**: it receives via webhook the structured data written to Mongo (with the `type` and `mode` details — always `Ingest`, see §2) and does embed + upsert in Qdrant.

**Architecture**: Mongo = canonical archive · Qdrant = rebuildable index, updated **exclusively via the n8n webhook** (never directly by this skill). Embedding model change = new Qdrant collection + re-embed from Mongo via n8n. No re-OCR needed.

**Config and schemas = single source in `document-extract`**: this skill has no local `config/` or `schemas/`. The scripts read `config/collections.yml` (routing `type` → Mongo DB/collection) and `schemas/*.json` (data contract + `pageContent_template` for the Qdrant content) **directly from the base skill folder** (`~/.claude/skills/document-extract/`). Changes to those files are made there, one copy only, no sync.

**Python environment**: the scripts use the `.venv/` of **this** skill (`pymongo`, `pyyaml`). It is not versioned and not present on other installs: `python3 -m venv .venv && .venv/bin/pip install pymongo pyyaml`.

**Skill folder**: the folder containing this `SKILL.md`. Relative paths (`scripts/`, `.env`) must be resolved from there.

## 1. How to use it (full flow)

1. **Extraction + Mongo** → use the **`document-extract`** skill (see its SKILL.md): the result is the record written to Mongo (idempotent upsert), with the preview approved by the user.
2. **Ingest into Qdrant** → come back here, with one of the two operations of §3.
3. **Verification** → on the webhook response (body, not HTTP status) or directly on Qdrant (read-only).

The field names are in **Italian snake_case** (e.g. `data_intervento`, `importo_totale`, `numero_documento`): they are part of the data contract with the workflow and must not be translated.

## 2. Payload contract towards the webhook

The payload to n8n has `type` and **`mode: "Ingest"`** (the only mode the workflow supports — **there is no `Rebuild`**). `id` = Mongo `_id` as a **string**, always at **top level**: it is the stable, unique key the delete node uses to avoid duplicates. `type`/`mode` are at the top **and also inside `metadata`**.

- **Types managed by n8n** (Bollette/Pedaggi): the payload is the raw record + `id`/`type`/`mode` + `metadata` = full Mongo record (the workflow builds the content reading the fields from `$json.metadata.*` — without the record in metadata the output comes out full of "undefined").
- **Types managed by the skill** (e.g. Veicoli — the schema with `pageContent_template` is in `document-extract/schemas/`): payload `{id, type, mode, pageContent, metadata}` — the `pageContent` arrives **ready-made**, rendered from the schema template (see `build_payload()` in `scripts/rebuild_qdrant.py`); `metadata` = full Mongo record + `id`/`type`/`mode`.

## 3. The two operations

| Operation | When | Script |
|-----------|------|--------|
| **Delta** (single record) | Day-to-day work: new document, correction, missing record | `scripts/push_to_n8n.py` |
| **Re-index (partial or full)** | First population, index issues, infrastructure changes, embedding change | `scripts/rebuild_qdrant.py` |

- **Delta — `scripts/push_to_n8n.py`**: after `document-extract` wrote the record to Mongo, it sends **that single record** to the webhook (`mode: Ingest`). The record is identified by the Mongo `_id` or a JSON filter; the type is taken from the record (`--type` to force it). Supports `--dry-run` to inspect the payload before sending. The dedup via the delete node replaces the point if the record changes.
- **Re-index — `scripts/rebuild_qdrant.py`**: reads the records back from Mongo (default: all the types of the base skill's `config/collections.yml`) and sends them to the webhook with `mode: Ingest`. Options: `--db <db>`, `--types <t>...`, `--limit N` (test), `--dry-run`, `--yes`. With `--limit`/`--dry-run` it skips the confirmation, otherwise it asks before proceeding. **Not for routine use** (see §5).

**Dedup = delete node, NOT a point-ID upsert**: the Qdrant node is `mode: insert` without a point ID parameter. Before the insert, the "Safe delete previous version" node deletes the points filtered by `{"key": "metadata.id", "match": {"value": "{{ $json.id }}"}}`: re-sending the same record → the previous point is replaced, never duplicated. The `$json` must reach the delete node unchanged (it must contain `id`).

## 4. Verification and auth

- **Verification = response body, NOT the HTTP status**: the webhook replies `200` even when the ingest fails. Success is judged on the body, which must be a JSON array with the Qdrant documents. The text is stored in the **`content`** field (types managed by n8n: Bollette/Pedaggi) or `pageContent` (types generated by the skill: Veicoli). Empty body or no content = failed ingest (e.g. the `type` branch is not wired in the workflow). `rebuild_qdrant.py` and `push_to_n8n.py` already apply this check (`has_qdrant_content`).
- **Webhook auth**: header `n8n-api-key: <N8N_API_KEY>` (value from `.env`). The domain sits behind **Cloudflare**: a browser User-Agent is required, otherwise it replies `403 error code: 1010`.
- **Final check (Qdrant, read-only)**: confirm the point exists directly with `scripts/verify_qdrant.py <id_mongo>` — it queries Qdrant via API using `QADRANT_URL`/`QADRANT_API_KEY` from `.env` (without the api-key, a Qdrant with authentication replies `403`). Alternatively, the Qdrant dashboard in the browser (filter `metadata.type` or `metadata.id`).

## 5. Guardrails

- **Delta only — never a global re-index in routine**: in day-to-day operations (new documents, corrections, missing records) do NOT clean and do NOT relaunch the full Qdrant re-index: work **only on the delta** (`push_to_n8n.py` for the single record; the dedup via the delete node replaces the point if it changes). The global re-index (`rebuild_qdrant.py`) is an **initial/one-off or extraordinary** operation — already done, do not repeat it in routine.
- **Writes ONLY via the n8n webhook, reads read-only**: every ingest goes through the n8n webhook; the only direct access to Qdrant is **read-only verification** (`verify_qdrant.py`: scroll filtered by `metadata.id`/`metadata.type`, never direct writes or deletes).
- **Preview before writing**: inherited from `document-extract` — no Mongo write (and therefore no ingest) without a preview approved by the user.

## 6. Known cases / gotchas

- **Body check** (see §4): HTTP 200 does not mean the ingest succeeded — always look at the body. `has_qdrant_content` is the rule to apply.
- **Veicoli routing in n8n**: the Type Switch has dedicated branches for Bollette/Pedaggi; types without a branch (e.g. Veicoli) must use the fallback with the payload `pageContent`, NOT the bills normalizer (otherwise the content comes out as "Bolletta ... undef").
- **Corrupted data `undefined-undefined-<date>`**: when the pre-ingest transformation fails on a date, a string like `undefined-undefined-<date>` can remain in Mongo, and the n8n content passes it to the Qdrant point. ALWAYS check Mongo with `{"$regex": "undefined"}` on all string fields before a re-index. The record must be fixed via **`document-extract`** (recover the exact date from the original source, normalize to ISO `YYYY-MM-DD`), then re-ingest the single record (the dedup replaces the point).
- **Single-record test** (dedup): clean collection → send the same record **2 times** → in Qdrant there must remain **1 point** with the correct `metadata.id` and content. 2 points = the delete node does not match (filter `metadata.id`/value `$json.id` or payload without `id` at the top).

> Auth, `mode` and the **body check** of the n8n webhook are documented in §4 and in the scripts: do not repeat them here.

## 7. Quick commands

```bash
# Extraction + Mongo: use document-extract (see its SKILL.md)

# Delta: send the single record just written to Mongo
.venv/bin/python3 scripts/push_to_n8n.py <id_mongo> --dry-run   # inspect the payload
.venv/bin/python3 scripts/push_to_n8n.py <id_mongo>             # send to the webhook

# Full re-index in Qdrant (re-reads Mongo, sends to the webhook with mode: Ingest)
.venv/bin/python3 scripts/rebuild_qdrant.py --db Bollette       # one DB only
.venv/bin/python3 scripts/rebuild_qdrant.py --dry-run          # preview without sending
.venv/bin/python3 scripts/rebuild_qdrant.py --limit 2 --yes    # test: 2 records per collection

# Direct Qdrant check (read-only; uses QADRANT_URL/QADRANT_API_KEY from .env)
.venv/bin/python3 scripts/verify_qdrant.py <id_mongo>          # point by metadata.id
.venv/bin/python3 scripts/verify_qdrant.py --type Veicoli      # points by metadata.type
```
